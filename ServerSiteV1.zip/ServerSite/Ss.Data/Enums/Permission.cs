﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ss.Data.Enums
{
    public enum Permission
    {
        User = 0,
        Admin = 1
    }
}
